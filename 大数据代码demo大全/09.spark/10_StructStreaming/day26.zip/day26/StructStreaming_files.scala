package day26

import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.sql.types.StructType

object StructStreaming_files {

  def main(args: Array[String]): Unit = {
    //需求   统计年龄小于25岁的人群的爱好排行榜

    //1 创建sparksession
    //1  创建sparksession
    val spark: SparkSession = SparkSession.builder()
      .master("local[*]")
      .appName("StructStreaming_socket")
      .getOrCreate()
    //准备数据的结构
  val Structtype: StructType = new StructType()
    .add("name","string")
    .add("age","integer")
    .add("hobby","string")

    //2  接收数据
    val jsonDatas: DataFrame = spark.readStream.schema(Structtype).json("F:\\传智播客\\传智专修学院\\第二学期\\34\\05-Spark\\资料")

    //3  根据业务处理和计算数据
    import  spark.implicits._

    val hobby: Dataset[Row] = jsonDatas.filter($"age"<25).groupBy("hobby").count().sort($"count".desc)

    //4 输出数据
    hobby.writeStream
      .format("console")
      .outputMode("complete")
      .start()
      .awaitTermination()
  }
}
