package day26

import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object StructStreamingKafka {
  def main(args: Array[String]): Unit = {
    //准备环境
    val spark: SparkSession = SparkSession.builder()
      .appName("StructStreamingFile")
      .master("local[*]")
      .getOrCreate()
    //设置日志级别
    spark.sparkContext.setLogLevel("WARN")

    //读取数据
    val kafkaDatas: DataFrame = spark.readStream.format("kafka")
                                .option("kafka.bootstrap.servers","node01:9092,node02:9092,node03:9092")
                                .option("subscribe","18BD12")
                                .load()

    //kafkaDatas  内的数据是kafka的数据（key,value）
    import  spark.implicits._
    val kafkaDatasString: Dataset[(String, String)] = kafkaDatas.selectExpr("CAST(key AS string)","CAST(value AS string)").as[(String,String)]
    //处理
    val word: Dataset[String] = kafkaDatasString.flatMap(a=>a._2.split(" "))
    //调用DSL语句进行计算
    val wordCount: Dataset[Row] = word.groupBy("value").count().sort($"count".desc)

    //输出
    wordCount.writeStream.format("console")
      .outputMode("complete")
      .start()
      .awaitTermination()

  }

}
