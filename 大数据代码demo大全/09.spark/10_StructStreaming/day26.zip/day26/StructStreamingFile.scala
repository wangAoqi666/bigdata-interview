package day26

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object StructStreamingFile {

  def main(args: Array[String]): Unit = {

    //创建sparksession
    val spark: SparkSession = SparkSession.builder()
      .appName("StructStreamingFile")
      .master("local[*]")
      .getOrCreate()
    //设置日志级别
    spark.sparkContext.setLogLevel("WARN")
    //读取数据
    //设置数据的结构
    val structType: StructType = new StructType()
      .add("name", "string")
      .add("age", "integer")
      .add("hobby", "string")

    val fileDatas: DataFrame = spark.readStream.schema(structType).json("F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料")
    import spark.implicits._
    //计算数据  统计年龄小于25岁的人群的爱好排行榜
    val hobby: Dataset[Row] = fileDatas.filter($"age" < 25).groupBy("hobby").count().sort($"count".asc)
    //数据输出
    hobby.writeStream.format("console")
      .outputMode("complete")
      .start()
      .awaitTermination()
  }
}
