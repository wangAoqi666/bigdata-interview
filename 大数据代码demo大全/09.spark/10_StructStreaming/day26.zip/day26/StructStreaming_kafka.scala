package day26

import org.apache.spark.SparkContext
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.sql.streaming.Trigger

object StructStreaming_kafka {
  def main(args: Array[String]): Unit = {
    //1  创建sparksession
    val spark: SparkSession = SparkSession.builder()
      .master("local[*]")
      .appName("StructStreaming_socket")
      .getOrCreate()

    val sc: SparkContext = spark.sparkContext
    sc.setLogLevel("WARN")

    //2  读物实时数据  数据(key  value)不是字符串
     val kafkaDatasRow: DataFrame = spark.readStream.format("kafka")
       .option("kafka.bootstrap.servers","node01:9092,node02:9092,node03:9092")
       .option("subscribe","18BD34")
       .load()

    import  spark.implicits._
    val kafkaDatasString: Dataset[(String, String)] =
        kafkaDatasRow.selectExpr("CAST(key AS String)","CAST(value AS String)").as[(String,String)]

     //3 数据预处理和数据计算
     val Word: Dataset[String] = kafkaDatasString.flatMap(a=>a._2.split(" "))

    //使用DSL （SQL）对数据进行计算
    val StructWordCount: Dataset[Row] = Word.groupBy("value").count().sort($"count")

    //4 输出（启动-等待关闭）
    StructWordCount.writeStream
      .trigger(Trigger.ProcessingTime(0))  //尽快执行
      .format("console")  //数据输出到控制台
      .outputMode("complete")  //输出所有数据
      .start()  //开始计算
      .awaitTermination()  //=等待关闭
  }
}
