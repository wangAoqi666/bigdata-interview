package day26

import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object StructStreamingSocket {

  def main(args: Array[String]): Unit = {

    //1 创建sparksession
    val spark: SparkSession = SparkSession.builder()
      .appName("StructStreamingSocket")
      .master("local[*]")
      .getOrCreate()
    //设置日志级别
    spark.sparkContext.setLogLevel("WARN")

    //2 接入/读物最新数据    socketDatas内的数据为Row
    val socketDatasRow: DataFrame = spark.readStream.format("socket")
                                .option("host","node01")
                                .option("port","9999")
                                .load()

    //3 根据业务进行预处理   和计算
    import  spark.implicits._
    val socketDatasString: Dataset[String] = socketDatasRow.as[String]
    //对数据进行拆分
    val Word: Dataset[String] = socketDatasString.flatMap(a=>a.split(" "))
    //计算单词的数量   DSL(类似sql)计算
    val wordCount: Dataset[Row] = Word.groupBy("value").count().sort($"count")

    //4 计算结果输出
    wordCount.writeStream.format("console")//数据输出到哪里
      .outputMode("complete") //输出所有数据
      .trigger(Trigger.ProcessingTime(0))  //尽快计算
      .start()  //开始任务
      .awaitTermination()  //等待关闭

  }
}
