package day23

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object udf {

  def main(args: Array[String]): Unit = {
    //1  创建sparksession
    val spark: SparkSession = SparkSession.builder().appName("Demo01").master("local[*]").getOrCreate()
    //2 创建sc
    val sc: SparkContext = spark.sparkContext
    //3 读取数据并加工
    val udfDatas: RDD[String] = sc.textFile("F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料\\udf.txt")

    import spark.implicits._
    val udfDF = udfDatas.toDF()

    //编写UDF函数   将数据中的小写字符转换为大写
    spark.udf.register("toUpperAdd123",(str:String)=>{
      //根据业务逻辑对数据进行处理
      //str.toUpperCase()+ " 123"
      //str.length*10
      str.length*10/2/2.toDouble
    })

    udfDF.show()
    udfDF.createOrReplaceTempView("udfTable")
    spark.sql("select value , toUpperAdd123(value) from udfTable ").show()

    sc.stop()
    spark.stop()
  }
}
