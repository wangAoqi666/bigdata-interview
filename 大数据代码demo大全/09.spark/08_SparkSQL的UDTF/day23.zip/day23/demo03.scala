package day23

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object demo03 {

  //准备临时存储数据的样例类
  case class Person(id:Int,name:String,age:Int)

  def main(args: Array[String]): Unit = {
    //1  创建sparksession
    val spark: SparkSession = SparkSession.builder().appName("Demo01").master("local[*]").getOrCreate()
    //2 创建sc
    val sc: SparkContext = spark.sparkContext
    //3 读取数据并加工
    val ttDatas: RDD[String] = sc.textFile("F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料\\tt.txt")
    val ttRDD: RDD[Array[String]] = ttDatas.map(a=>a.split(" "))
    val PersonRDD: RDD[Person] = ttRDD.map(z=>Person(z(0).toInt,z(1),z(2).toInt))
    // 引入隐式转换
    import spark.implicits._

    //RDD转DF
    val personDF: DataFrame = PersonRDD.toDF()

    //5  注册成表并查询
    personDF.show()
    personDF.printSchema()

    //第一种数据查询方法
    personDF.createOrReplaceTempView("personDF")
    spark.sql("select * from personDF where age>25").show()

    //第二种方法dsl
    personDF.select("name","age").filter($"age">25).show()


    //RDD、DF、DS相互转化

      //RDD  -> DF   DS
      //在引入隐式转换的前提下
        PersonRDD.toDF()
        PersonRDD.toDS()

      //DF   ->RDD   DS
        personDF.rdd
        val dataSet: Dataset[Person] = personDF.as[Person]

      //DS   ->rdd  DF
        dataSet.rdd
        dataSet.toDF()

      /*
       转换成RDD    .rdd
       转换成DF     .toDF()
       转换成DS
              RDD->DS      .toDS()
               DF->DS      .as[Person]
       */


    personDF.write.json("F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料\\json")


    //6 关闭sc    sparksession
    sc.stop()
    spark.stop()
  }
}
