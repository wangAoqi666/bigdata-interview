package day23

import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object udaf {


  class GetAvg extends   UserDefinedAggregateFunction{
    //设置  输入的数据的类型
    override def inputSchema: StructType = {
      StructType(List(StructField("input",LongType)))
    }

    //设置缓存中间结果数据
    //sum : 每次的临时的和
    //total:  临时的总次数
    override def bufferSchema: StructType = {
      StructType(List(StructField("sum",LongType),StructField("total",LongType)))
    }

    //最终的返回的数据的类型
    override def dataType: DataType ={
      DoubleType
    }

    //相同的输入否会有相同的输出
    override def deterministic: Boolean = {
      true
    }

    //设置X 个变量    每个变量进行初始化数据
    override def initialize(buffer: MutableAggregationBuffer): Unit = {
      //算法总和/总数
      // buffer(0)用于记录临时的数据和
      buffer(0)=0L
      //buffer(1)用于记录临时的数据条数
      buffer(1)=0L
    }

    /*
    {"name":"Michael","salary":3000}
    {"name":"Andy","salary":4500}



    {"name":"Justin","salary":3500}
    {"name":"Berta","salary":4000}
     */

    //List（1,2,3,4,5,6）.reduce((a,b)=>a+b)
    /*
    1  a=1  b=2
    2  a=3  b=3
    3  a=6  b=4
    4  a=10 b=5
    5
    6
     */
    //RDD 中含有多个分区    update是计算一个分区内的数据
    override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
      //临时输入的总金额
      //buffer.getLong(0)  上次缓存的数据
      //input.getLong(0)   最新输入的数据
      buffer(0)=buffer.getLong(0)+input.getLong(0)

      //临时输入的总数量（条数）
      buffer(1)=buffer.getLong(1)+1

    }

    //上面的update有一个rdd分区就会有几个最终结果（上面的有两个结果【临时金额和/临时数量】）
    //合并计算不同分区的结果
    override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
      //累加第一个分区金额总和   与第二个分区金额总=最终的中金额
      buffer1(0)=buffer1.getLong(0)+buffer2.getLong(0)
      //累加第一个分区次数 与第二个分区次数=最终的总次数
      buffer1(1)=buffer1.getLong(1)+buffer2.getLong(1)
    }

    //计算最终的平均值
    override def evaluate(buffer: Row): Any = {
      buffer.getLong(0).toDouble/buffer.getLong(1).toDouble
    }
  }





  def main(args: Array[String]): Unit = {

    //1  创建sparksession
    val spark: SparkSession = SparkSession.builder().appName("Demo01").master("local[*]").getOrCreate()
    val udafJsonDatas: DataFrame = spark.read.json("file:///F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料\\udaf.json")

    udafJsonDatas.show()
    udafJsonDatas.createOrReplaceTempView("UdafTable")

    //注册一个UDAF函数
    spark.udf.register("GetAvg",new GetAvg())

    //查看薪水
    spark.sql("select GetAvg(salary) from UdafTable").show()
    spark.sql("select avg(salary) from UdafTable").show()

    spark.stop()

  }


}
