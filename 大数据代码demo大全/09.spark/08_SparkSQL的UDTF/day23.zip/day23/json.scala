package day23

import org.apache.spark.sql.{DataFrame, SparkSession}

object json {

  def main(args: Array[String]): Unit = {

    //1  创建sparksession
    val spark: SparkSession = SparkSession.builder().appName("Demo01").master("local[*]").getOrCreate()
    //spark读取数据
    val frame: DataFrame = spark.read.json("file:///F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料\\people.json")

    frame.show()
    spark.stop()

  }


}
