package day23

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

object demo01 {
  def main(args: Array[String]): Unit = {

    //1  创建sparksession
       val spark: SparkSession = SparkSession.builder().appName("Demo01").master("local[*]").getOrCreate()

    //2 创建sc
    val sc: SparkContext = spark.sparkContext

    //3 读取数据并加工
    val ttDatas: RDD[String] = sc.textFile("F:\\传智播客\\传智专修学院\\第二学期\\12\\05-Spark\\资料\\tt.txt")
    val ttRDD: RDD[(Int, String, Int)] = ttDatas.map(a=>a.split(" ")).map(z=>(z(0).toInt,z(1),z(2).toInt))

    //4 设置表结构
      //引入隐式转换
      import  spark.implicits._
    //转化成DF
    val ttDF: DataFrame = ttRDD.toDF("id","name","age")

    //5  注册成表并查询
    ttDF.show()
    ttDF.printSchema()


    //第二种方法dsl
    ttDF.select("name","age").filter($"age">25).show()


    //6 关闭sc    sparksession
    sc.stop()
    spark.stop()

  }
}
